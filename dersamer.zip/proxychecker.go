package main

import (
    "fmt"
    "io/ioutil"
    "net/http"
    "os"
    "strings"
    "sync"
    "time"
	url2 "net/url"
)

func checkProxy(proxy string, wg *sync.WaitGroup) {
    defer wg.Done()

	proxyURL, err := url2.Parse("http://" + proxy)
	if err != nil {
		return
	}
	
    url := "http://example.com"
    client := &http.Client{
        Transport: &http.Transport{
            Proxy: http.ProxyURL(proxyURL),
        },
        Timeout: 5 * time.Second,
    }

    resp, err := client.Get(url)
    if err != nil {
        fmt.Printf("[Nxver] Proxy %s - Error\n", proxy)
        return
    }
    defer resp.Body.Close()

    body, err := ioutil.ReadAll(resp.Body)
    if err != nil {
        fmt.Printf("[Nxver] Proxy %s - Error\n", proxy)
        return
    }

    if strings.Contains(string(body), "<h1>Example Domain</h1>") {
		file, err := os.OpenFile("valid-proxies.txt", os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {}
		defer file.Close()
		fmt.Fprintf(file, "%s\n", proxy)
        fmt.Printf("[Nxver] Proxy %s - Alive\n", proxy)
    } else {
        fmt.Printf("[Nxver] Proxy %s - Error\n", proxy)
    }
}

func readProxiesFromFile(filename string) []string {
    data, err := ioutil.ReadFile(filename)
    if err != nil {
        fmt.Printf("Error reading file: %s\n", err)
        os.Exit(1)
    }

    lines := strings.Split(string(data), "\n")
    proxies := make([]string, 0, len(lines))

    for _, line := range lines {
        line = strings.TrimSpace(line)
        if line != "" {
            proxies = append(proxies, line)
        }
    }

    return proxies
}

func writeProxiesToFile(filename string, proxies []string) {
    data := strings.Join(proxies, "\n")
    err := ioutil.WriteFile(filename, []byte(data), 0644)
    if err != nil {
        fmt.Printf("Error writing file: %s\n", err)
        os.Exit(1)
    }
}

func checkAndSaveValidProxies() {
    allProxies := readProxiesFromFile("hui.txt")
    validProxies := make([]string, 0, len(allProxies))

    var wg sync.WaitGroup
    wg.Add(len(allProxies))

    for _, proxy := range allProxies {
        go checkProxy(proxy, &wg)
    }

    wg.Wait()

    for _, proxy := range allProxies {
        if strings.Contains(string(proxy), "Alive") {
            validProxies = append(validProxies, proxy)
        }
    }

  //  writeProxiesToFile("valid-proxies.txt", validProxies)
}

func checkAndRemoveBrokenProxies() {
    validProxies := readProxiesFromFile("valid-proxies.txt")
    workingProxies := make([]string, 0, len(validProxies))

    var wg sync.WaitGroup
    wg.Add(len(validProxies))

    for _, proxy := range validProxies {
        go checkProxy(proxy, &wg)
    }

    wg.Wait()

    for _, proxy := range validProxies {
        if strings.Contains(string(proxy), "Alive") {
            workingProxies = append(workingProxies, proxy)
        }
    }

    writeProxiesToFile("valid-proxies.txt", workingProxies)
}

func main() {
    hours := 4
    interval := time.Duration(60 * 60 * 1000 * time.Millisecond)

    for i := 0; i < hours; i++ {
        go func() {
            for {
                checkAndSaveValidProxies()
                time.Sleep(interval)
            }
        }()
    }

    go func() {
        for {
            checkAndRemoveBrokenProxies()
            time.Sleep(24 * time.Hour)
        }
    }()

    select {}
}